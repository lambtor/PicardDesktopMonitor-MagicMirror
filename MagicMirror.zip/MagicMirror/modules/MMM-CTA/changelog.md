Changelog for changes made and things to do

# Version 0.0.1

- To do: fix node helper nested request strips, add case for if train gets error after bus

- To do: Create conditionals for requests, based on if API keys are set for bus only, train only, or bus and train

- To do: Create full readme file that matches MMM specifications

- To do: After fixes, proof for other things need to change; if nothing else to change release to community

- To do: Add multi-instance option:  Can be done by setting an instance variable in config, and then using socketNotification with instance ID

- To do: Fix max result of bus and train

# Version 0.0.2

- Addressed all issues under version 0.0.1 and issue #1

- To do:  Add bus coloring options based on 'L' train color
