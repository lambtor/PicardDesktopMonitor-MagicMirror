Module.register("MMM-CTA", {
	defaults: { // Start with the information needed for a single stop
		busStopName: null,
		// stationId: null,
		stopId: null,
		maxResult: null,
		maxResultTrain: null,
		routeCode: null,
		ctaApiKey: null,
		updateTime: 300000, // 5 minutes
		busUrl: 'http://www.ctabustracker.com/bustime/api/v2/getpredictions', // deleted http:
		// initialLoadDelay: 0, // This is obsolete, loaded first call by start()
		trainUrl: 'http://lapi.transitchicago.com/api/1.0/ttarrivals.aspx',
		ctaApiKeyTrain: null,
		trainStationID: null,
		trainStopName: null,
		moduleInstance: 1,
		trainIconColor: 'auto'
	},

	// requireVersion: 

	getStyles: function() {
		return ["font-awesome.css"];
	},

/*	loader: function() {
		var loader = document.createElement("div");
		loader.innerHTML = ("LOADING CTA TRACKER");
		loader.className = "small dimmed";
		return loader;
		this.loaded = false;
		Log.log("Loader run.")
	},
*/
	header: function() {
		var header = document.createElement("header");
		header.innerHTML = this.config.busStopName;
		return header;
	},

	apiRequest: function(self) {
		// Variables needed for API request, see CTA developer documentation
		var request = {
			// mapid: self.config.stationId,
			stpid: self.config.stopId,
			maxRes: self.config.maxResult,
			maxResTrain: self.config.maxResultTrain,
			rt: self.config.routeCode,
			key: self.config.ctaApiKey,
			urlBus: self.config.busUrl,
			updateInterval: self.config.updateTime,
			urlTrain: self.config.trainUrl,
			keyTrain: self.config.ctaApiKeyTrain,
			idTrain: self.config.trainStationID,
			modInstance: self.config.moduleInstance
		};
		self.sendSocketNotification("CTA-REQUEST", request);  // Socket notification processed in node_helper.js;
	},

	getDom: function() {
		// console.log("Updating CTA dom"); // testing, make sure updateDom is running
		var self = this;
		// Create document container
		wrapper = document.createElement("div");
		//assign class name to wrapper - this is necessary to override the massive padding/margins between
		//multiple stop definitions
		wrapper.className = "trainschedulediv";
		// create table
		var table = document.createElement("table");
		table.className = "trainstoptable";

		if (this.dataNotification) {
			if (this.dataNotification.train !== null) {
				let nLength = 0;
				try {
					if (this.dataNotification.train["ctatt"] !== undefined && this.dataNotification.train["ctatt"].eta !== undefined) {
						nLength = this.dataNotification.train["ctatt"].eta.length;
					}
				} catch (oErr1) {
					//let the loop run, since it'll do nothing with length defaulted to 0
				}
				
				// Do the train content row with a loop
				for (i = 0, len = nLength; i < nLength; i++) {
					let sTrainIconColor = "inherit";
					if (this.config.trainIconColor.toLowerCase() != "auto") {
						sTrainIconColor = this.config.trainIconColor;
					} else {
						sTrainIconColor = this.dataNotification.train["ctatt"].eta[i].rt.toUpperCase();
						/* train route name abbreviations - convert abbreviations to usable colors for icons
							Red = Red Line (Howard-95th/Dan Ryan service)
							Blue = Blue Line (O’Hare-Forest Park service)
							Brn = Brown Line (Kimball-Loop service)
							G = Green Line (Harlem/Lake-Ashland/63rd-Cottage Grove service)
							Org = Orange Line (Midway-Loop service)
							P = Purple Line (Linden-Howard shuttle service)
							Pink = Pink Line (54th/Cermak-Loop service)
							Y = Yellow Line (Skokie-Howard [Skokie Swift] shuttle service)
						*/
						switch(sTrainIconColor) {
							case "P":
								sTrainIconColor = "PURPLE";
								break;
							case "PEXP":
								sTrainIconColor = "PURPLE";
								break;
							case "BRN":
								sTrainIconColor = "BROWN";
								break;
							case "RED":
								sTrainIconColor = "RED";
								break;
							case "ORG":
								sTrainIconColor = "ORANGE";
								break;
							case "BL":
								sTrainIconColor = "BLUE";
								break;
							case "G":
								sTrainIconColor = "GREEN";
								break;
							case "Y":
								sTrainIconColor = "YELLOW";
								break;
							default: 
								break;
						}
					}
					var arriveRow = document.createElement("tr");
					arriveRow.className = "xsmall";
					arriveRow.align = "left";

					//if first row, create first column as stop
					if (i == 0) {
						var stopNameCell = document.createElement("td");
						//stopNameCell.align = "right";
						//stopNameCell.vertical-align = "top";
						stopNameCell.innerHTML = this.config.trainStopName + "<br/>" + moment().format("HH:mm") + "";
						stopNameCell.rowSpan = this.config.maxResultTrain;
						stopNameCell.className = "medium trainstopname datalabel";						
						arriveRow.appendChild(stopNameCell);
					}
					
					//estimated arrival time first
					var arrivalArriveElement = document.createElement("td");
					//arrivalArriveElement.align = "right";
					var arrivalT = moment(this.dataNotification.train["ctatt"].eta[i].arrT);
					var now = moment();
					var duration = moment.duration(arrivalT.diff(now));
					var arrivalTime = Math.round(duration.asMinutes());
					arrivalArriveElement.className = "trainETA trainETAfont";
					arrivalArriveElement.innerHTML = this.dataNotification.train["ctatt"].eta[i].isDly == 0 ? "" : "! ";
					arrivalArriveElement.innerHTML += arrivalTime < 0 ? "LATE" : (arrivalTime == 0 ? "DUE" : (arrivalTime + " MIN").toUpperCase());
					arriveRow.appendChild(arrivalArriveElement);

					//train direction
					var arriveElement = document.createElement("td");
					arriveElement.innerHTML = this.dataNotification.train["ctatt"].eta[i].destNm.toUpperCase().split("/")[0];
					//if (arriveElement.innerHTML.indexOf(",") > -1) {
					//arriveElement.innerHTML = arriveElement.innerHTML.split(",")[0];
					//}
					arriveElement.className = "trainroutedestinationname trainETAfont";
					arriveRow.appendChild(arriveElement);

					//train type/line name
					var rtArriveElement = document.createElement("td");
					//rtArriveElement.align = "right";
					rtArriveElement.className = "trainETA trainETAfont";
					//rtArriveElement.innerHTML = "<i class='fa fa-subway' style='color:" + sTrainIconColor + ";'></i>  "; // Add options for other train colors
					rtArriveElement.innerHTML += sTrainIconColor;
					arriveRow.appendChild(rtArriveElement);

					// Append trainArrivalRow into table!
					table.appendChild(arriveRow);
				}
			}
		};
		wrapper.appendChild(table);
		return wrapper;
	},

	/* scheduleUpdate()
	* Schedule next update.
	* this.config.updateInterval is used.
	* see:  https://github.com/nwootton/MMM-UKLiveBusStopInfo */
	scheduleUpdate: function() {
        var nextLoad = this.config.updateTime;
		var nInstanceRefTimer = (this.config.moduleInstance-1) * 4000;
		var nNextLoad = nextLoad + nInstanceRefTimer;
        var self = this;
		clearTimeout(this.updateTimer);
        this.updateTimer = setInterval(function() {
			try {
				//this is throwing an exception REALLY FREQUENTLY for "apiRequest is not a function"
				self.apiRequest(self);			
			} catch(oErr) {
			//	console.log("instance: " + this.config.moduleInstance);
				let oTemp = oErr.message;
			}
		//}, nextLoad);
		}, nNextLoad);
    },

	socketNotificationReceived: function (notification, payload) {
		if (notification === this.instanceData) {
			// send payload (aka bus/train data to new var = dataNotification)
			//console.log("Payload received");			
			this.dataNotification = payload;
			this.updateDom();
			// this.scheduleUpdate(this.config.updateTime); NO LONGER NEED SINCE USING setInterval()
			
			//trigger theme persist
			//force dom update to trigger theme refresh via mmm-buttons
			//Log.log("theme persist request sent cta");
			this.sendNotification("THEME_PERSIST", {});
		} else if (notification.startsWith("MMM-CTA-DATA")) {
			//Log.log("theme persist request backup send cta");
			this.sendNotification("THEME_PERSIST", {});
		}
	},
	
	start: function() {
		Log.log("Starting module: MMM-CTA");
		//console.log("MMM-CTA started console logged.");
		// Prevent API abuse, bus tracker limits 10,000/day
		if (this.updateTime < 60000) {
			this.updateTime = 60000 // Every 1 min (overkill as they don't update API that often);
		};
		this.loaded = false;
		this.instanceData = "MMM-CTA-DATA" + this.config.moduleInstance;
		// this.instanceReq = "CTA-REQUEST" + this.config.moduleInstance;
		// Initial run to start;
		
		if (this.config.moduleInstance > 0) {
		//if (this.config.moduleInstance == 1) {
			this.apiRequest(this);
			this.scheduleUpdate();
		//} else if (this.config.moduleInstance > 1) {			
		//	setTimeout(this.apiRequest, 4000 * this.config.moduleInstance, this);
		//	setTimeout(this.scheduleUpdate, 4000 * this.config.moduleInstance);
			
			/*setTimeout(this.apiRequest(this), 4000 * this.config.moduleInstance);
			setTimeout(this.scheduleUpdate(), 4000 * this.config.moduleInstance);*/
		};
	
	}
});
