Module.register("MMM-BurnIn", {

    defaults: {
        updateInterval: 15,
	invertDuration: 5
    },

    getStyles: function () {
        return [];
    },

    start: function () {		
        setInterval(() => {
            this.sendSocketNotification("DO_ANTI_BURNIN", this.config);
        }, this.config.updateInterval * 60 * 1000);
        setInterval(() => {
            this.sendSocketNotification("DO_ANTI_BURNIN2", this.config);
        }, this.config.invertDuration * 1000);

    },

    getDom: function () {
        return document.createElement("span");
    },

/*
startAntiBurnin: function() {
	document.getElementsByTagName("body").item(0).classList.add("fullInverted");
	this.updateDom(1000);
	setTimeout(() => {
	document.getElementsByTagName("body").item(0).classList.remove("fullInverted");
	this.updateDom(1000);
	}, this.config.invertDuration * 1000);
	setTimeout(() => {
			this.startAntiBurnin();
		}, this.config.updateInterval * 60 * 1000);
	},
*/

socketNotificationReceived: function (notification, payload) {
	/*if (notification.toLowerCase().includes("burnin") ) {
		console.log("antiburnin " + notification);
	}*/

        if (notification === "ANTI_BURNIN" || notification === "DO_ANTI_BURNIN") {
       	document.getElementsByTagName("body").item(0).classList.add("fullInverted");
	this.updateDom(1000);
        } else if (notification === "ANTI_BURNIN2" || notification === "DO_ANTI_BURNIN2") {
        document.getElementsByTagName("body").item(0).classList.remove("fullInverted");
	this.updateDom(1000);
	}

    }
});
