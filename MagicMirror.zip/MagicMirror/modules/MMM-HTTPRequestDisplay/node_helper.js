var request = require("request");
var NodeHelper = require("node_helper");

module.exports = NodeHelper.create({
	// Process socket notification from MMM-CTA.js

	start: function() {
		this.config = null;
		this.instance = null;
	},

	getData: function(payload) {
		var self = this;
		//var busReady = false;
		//var trainReady = false;
		this.instance = "MMM-HTTPRequestDisplay" + payload.modInstance;
		//need to migrate this functionality over from CTA train because jagtard didn't maintain it or build it
		//to support CORS.
		
		if (payload.httpRequestURL != null && payload.httpRequestURL !== "") {
			self.getXML(payload.httpRequestURL);
		} else {
			console.log("No http request URL specified.");
		}
		// Functions for bus & train, bus, or train only
		//if (trainReady) {
		//	self.getTrain(myUrlTrain);
		//} else { 
		//	console.log("No complete bus or train configs found!!!"); 
		//};
	},	
	
	getXML: function(sHTTPURL) {
		var self = this;
		var xmlResp = null;
		var xmlParser = null;
		
		request({url: sHTTPURL}, function(error, response, body) {
			console.log("http req fired");
			if (!error && response.statusCode == 200) {
				//console.log(response);
				//xmlParser = new DOMParser();
				//xmlResp = xmlParser.parseFromString(body, "text/xml");
				//this notification gets sent back to mmm-httprequestdisplay
				self.sendSocketNotification(self.instance, response.body);
			}
		});
	},

	getTrain: function(myUrlTrain) {
		var self = this;
		var bodyJs = {
			bus: null,
			train: null
		};
		request({url: myUrlTrain}, function (error, response, body) {
			console.log("http request fired."); // for debugging
			// If no error, store in bodyJs
			if (!error && response.statusCode == 200) {
				//need to modify this to parse XML instead
				bodyJs.train = JSON.parse(body);
				console.log(bodyJs.train); // For testing purposes;
				self.sendSocketNotification(self.instance, bodyJs);
			}
		});
	},

	socketNotificationReceived: function(notification, payload) { 
		// Payload is 'request' from MMM-HTTPRequestDisplay
		var self = this;
		if (notification === "XMLREQUEST" ) {		
			self.config = payload;
			self.getData(payload);
		}
	}

});
