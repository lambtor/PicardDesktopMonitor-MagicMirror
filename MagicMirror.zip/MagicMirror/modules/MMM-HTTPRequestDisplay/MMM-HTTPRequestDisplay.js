/* Module */

/* Magic Mirror
 * Module: MMM-HTTPRequestDisplay
 *
 * By Eunan Camilleri eunancamilleri@gmail.com
 * v1.0 23/06/2016
 * MIT Licensed.
 */

Module.register("MMM-HTTPRequestDisplay",{

	// Default module config.
	defaults: {
		updateInterval: 300000, // every 5 minutes
		initialLoadDelay: 2500, // 2.5 seconds delay
		retryDelay: 2500, 		// retry delay
		animationSpeed: 2.5 * 1000, 	// animation speed
		httpRequestURL: "",
		updateTime: 300000,		//5 minutes
		moduleInstance: 1
	},

	// Define start sequence.
	start: function() {
		Log.info("Starting module: " + this.name);
		moment.locale(config.language);
		
		//pulled from MMM-CTA
		this.loaded = false;
		this.instanceData = "MMM-HTTPRequestDisplay" + this.config.moduleInstance;
		// Initial run to start;
		//if (this.config.moduleInstance === 1) {
			this.apiRequest(this);
			this.scheduleUpdate();
		//} else if (this.config.moduleInstance > 1) {
		//	setTimeout(this.apiRequest, 4000 * this.config.moduleInstance, this);
		//	setTimeout(this.scheduleUpdate, 4000 * this.config.moduleInstance);
		//}		
	},
	
	apiRequest: function(self) {
		// Variables needed for API request, see CTA developer documentation
		var request = {
			updateInterval: self.config.updateTime,
			modInstance: self.config.moduleInstance,
			httpRequestURL: self.config.httpRequestURL
		};
		self.sendSocketNotification("XMLREQUEST", request);  // Socket notification processed in node_helper.js;
	},

	// Define required scripts.
	//getStyles: function() {
	//	return ["httpreqdisplay.css"];
	//},
	getScripts: function() {
		return ["moment.js"];
	},

	// Override dom generator.
	getDom: function() {
		var self = this;
		//need to mimic html structure of RSS feeds. div / span marquee / span
		var wrapper = document.createElement("div");
		wrapper.className = "marqueeContainer";

		var oFeedLabel = document.createElement("span");
		oFeedLabel.className = "feedLabel newsfeed-desc light datalabel";
		oFeedLabel.innerHTML = "TRANSIT";
		var oMarquee = document.createElement("marquee");
		oMarquee.className = "marquee";
		
		var oMarqueeSpan = document.createElement("span");
		oMarqueeSpan.className = "newsfeed-source light";
		oMarqueeSpan.innerHTML = "";
		let xmlDoc = null;
		
		if (this.dataNotification && this.dataNotification !== null) {
			//format the xml returned by the node helper. this starts as raw text and needs header removed.
			//to-do: put whole thing in a try/catch
			var oParser = new DOMParser();			
			xmlDoc = String(this.dataNotification).includes("?>") ? oParser.parseFromString(this.dataNotification.split("?>")[1], "text/xml") : this.dataNotification;
			let i = 0;
			var sList = "";
			xmlItemList = xmlDoc.getElementsByTagName("RouteInfo");
			for (i = 0; i < xmlItemList.length; i++) {
				let sRouteName = xmlItemList[i].getElementsByTagName("Route")[0].textContent.toUpperCase();
				let sRouteStatus = xmlItemList[i].getElementsByTagName("RouteStatus")[0].textContent.toUpperCase();
				
				if (sRouteName === "PINK LINE" || sRouteName === "GREEN LINE" || sRouteName === "YELLOW LINE" || sRouteName === "ORANGE LINE")  {
					continue;
				}
				
				sList += "&bull; " + sRouteName;
				sList += " &middot; " + sRouteStatus + " ";
			}
			
			oMarqueeSpan.innerHTML = /*sList.startsWith("&bull;") ? sList.substring(7) :*/ sList;
			if (sList.length > 0) {
				var sTimeStamp = xmlDoc.getElementsByTagName("TimeStamp")[0].textContent;
				var sFormattedDate = ""; //sTimeStamp.substring(0,4) + "." + sTimeStamp.substring(4,6) + "." + sTimeStamp.substring(6,8);
				sList = sFormattedDate + " " + sTimeStamp.split(" ")[1] + "&nbsp;" + oMarqueeSpan.innerHTML.replace('"','');
			}
			
			oMarqueeSpan.innerHTML = sList;
			//wrapper.innerHTML = xmlDoc.getElementsByTagName("RouteInfo")[0].childNodes[0].nodeValue;
			//need a placeholder to prevent weird formatting issues?
			var oTempSpan = document.createElement("span");
			oTempSpan.className = "marqueespanouter";
			oTempSpan.appendChild(oMarqueeSpan);
			
			//oMarquee.appendChild(oMarqueeSpan);
			oMarquee.appendChild(oTempSpan);
			wrapper.appendChild(oFeedLabel);
			wrapper.appendChild(oMarquee);
						
		}		

		return wrapper;
	},
	
	

	wrapNodeTitle : function(node){
		var nodeTitle, nodeValue, container;
		container = document.createElement("div");
		nodeTitle = node[0];
		if(node[1] === null){
			nodeValue = "";
		}
		else {
			nodeValue = " : " + node[1];
		}
		container.className = "node-title center";
		container.innerHTML = nodeTitle + nodeValue;
		return container;
	},

	wrapAttribute : function(attribute){
		var container, attributeTitle, attributeValue;
		attributeTitle = attribute[0];
		container = document.createElement("div");
		if(attribute[1] === null){
			attributeValue = "No Value";
		}
		else {
			attributeValue = " : " + attribute[1];
		}
		container.className = "small center";
		container.innerHTML = attributeTitle + attributeValue;

		return container;
	},

	getNextValue : function(){
		var index = this.currentValueIndex;
		if(this.currentValueIndex + 1 === this.nodes.length-1){
			this.currentValueIndex = 0;
		}
		else {
			this.currentValueIndex++;
		}
		return this.nodes[index];
	},

	processData: function(data) {
		this.nodes = [];
		var x = data.documentElement.childNodes;

		for (i = 0; i < x.length; i++) {
			var attributes = [];
			for(j = 0; j < x[i].attributes.length; j++){
				attributes.push([x[i].attributes[j].nodeName, x[i].attributes[j].nodeValue]);
			}
			this.nodes.push([[x[i].nodeName, x[i].nodeValue], attributes]);
		}
		//this.nodes.push(["","",])
		this.loaded = true;
		this.updateDom(this.config.animationSpeed);
		
		//trigger theme persist
		//force dom update to trigger theme refresh via mmm-buttons
		//Log.log("theme persist request sent httpreqdisp");
		this.sendNotification("THEME_PERSIST", {});
		
	},
	
	/* scheduleUpdate()
	* Schedule next update.
	* this.config.updateInterval is used.
	* see:  https://github.com/nwootton/MMM-UKLiveBusStopInfo */
	scheduleUpdate: function() {
        var nextLoad = this.config.updateTime;
        var self = this;
        this.updateTimer = setInterval(function() {
			self.apiRequest(self);
		}, nextLoad);
    },
	
	socketNotificationReceived: function (notification, payload) {
		if (notification === this.instanceData) {
			// send payload (aka bus/train data to new var = dataNotification)
			//console.log("Payload received");			
			this.dataNotification = payload;
			this.updateDom(this.config.animationSpeed);
			//this.scheduleUpdate(this.config.updateTime); NO LONGER NEED SINCE USING setInterval()
			
			//trigger theme persist
			//force dom update to trigger theme refresh via mmm-buttons
			//Log.log("theme persist request sent httpreqdisp");
			this.sendSocketNotification("THEME_PERSIST", undefined);
		}
	}
	

});
