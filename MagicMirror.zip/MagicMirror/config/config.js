/* Config Sample
 *
 * For more information on how you can configure this file
 * see https://docs.magicmirror.builders/configuration/introduction.html
 * and https://docs.magicmirror.builders/modules/configuration.html
 *
 * You can use environment variables using a `config.js.template` file instead of `config.js`
 * which will be converted to `config.js` while starting. For more information
 * see https://docs.magicmirror.builders/configuration/introduction.html#enviromnent-variables
 */
let config = {
	address: "localhost",	// Address to listen on, can be:
							// - "localhost", "127.0.0.1", "::1" to listen on loopback interface
							// - another specific IPv4/6 to listen on a specific interface
							// - "0.0.0.0", "::" to listen on any interface
							// Default, when address config is left out or empty, is "localhost"
	port: 8080,
	basePath: "/",	// The URL path where MagicMirror² is hosted. If you are using a Reverse proxy
									// you must set the sub path here. basePath must end with a /
	ipWhitelist: ["127.0.0.1", "::ffff:127.0.0.1", "::1"],	// Set [] to allow all IP addresses
									// or add a specific IPv4 of 192.168.1.5 :
									// ["127.0.0.1", "::ffff:127.0.0.1", "::1", "::ffff:192.168.1.5"],
									// or IPv4 range of 192.168.3.0 --> 192.168.3.15 use CIDR format :
									// ["127.0.0.1", "::ffff:127.0.0.1", "::1", "::ffff:192.168.3.0/28"],

	useHttps: false,			// Support HTTPS or not, default "false" will use HTTP
	httpsPrivateKey: "",	// HTTPS private key path, only require when useHttps is true
	httpsCertificate: "",	// HTTPS Certificate path, only require when useHttps is true

	language: "en",
	locale: "en-US",   // this variable is provided as a consistent location
			   // it is currently only used by 3rd party modules. no MagicMirror code uses this value
			   // as we have no usage, we  have no constraints on what this field holds
			   // see https://en.wikipedia.org/wiki/Locale_(computer_software) for the possibilities

	logLevel: ["INFO", "LOG", "WARN", "ERROR"], // Add "DEBUG" for even more logging
	timeFormat: 24,
	units: "metric",

	modules: [
		/*{
			module: "alert",
		}, */
		/*{
			module: "clock",
			position: "middle_center",
			dateFormat: "YYYY.MM.DD",
			showPeriod: false,
			timeFormat: 24,
			showStarDate: 1
		},*/
		/*{
			module: "calendar",
			header: "US Holidays",
			position: "top_left",
			config: {
				calendars: [
					{
						fetchInterval: 7 * 24 * 60 * 60 * 1000,
						symbol: "calendar-check",
						url: "https://ics.calendarlabs.com/76/mm3137/US_Holidays.ics"
					}
				]
			}
		},*/
		/*{
			module: "weather",
			position: "top_bar",
			config: {
				weatherProvider: "openmeteo",
				type: "current",
				lat: 41.908331,
				lon: -87.643203,
				appendLocationNameToHeader: false,
				degreeLabel: true,
				units: "metric",
				scale: true,
				fade: false
			}
		},		
		{
			module: "weather",
			position: "top_bar",
			header: "Weather Forecast",
			config: {
				weatherProvider: "openmeteo",
				type: "forecast",
				lat: 41.908331,
				lon: -87.643203,
				appendLocationNameToHeader: false,
				degreeLabel: true,
				units: "metric",
				scale: true,
				fade: false
			}
		},*/
		{
			module: "clock2",
			position: "middle_center",
			dateFormat: "YYYY.MM.DD",
			showPeriod: false,
			timeFormat: 24,
			showStarDate: 1
		},
		{
			module: "weatherforecast",
			position: "top_bar",
			header: "Weather Forecast",
			config: {
				location: "CITYNAME",
				locationID: "12345",  //ID from http://bulk.openweathermap.org/sample/city.list.json.gz; 
				appid: "######",
				appendLocationNameToHeader: false,
				degreeLabel: true,
				units: "metric",
				scale: true,
				fade: false
			}
		},
		{
			module: "currentweather",
			position: "top_bar",
			config: {
				location: "CITYNAME",
				locationID: "12345",  //ID from http://bulk.openweathermap.org/sample/city.list.json.gz;
				appid: "######",
				degreeLabel: true,
				units: "metric"
			}
		},
		{
			module: "newsfeed",
			position: "bottom_bar",
			config: {
				feeds: [
					{
						title: "WORLD",
						url: "http://feeds.bbci.co.uk/news/world/rss.xml"
					},
					{
						title: "TECHNOLOGY",
						url: "http://feeds.bbci.co.uk/news/technology/rss.xml"
					},
					{
						title: "SCIENCE",
						url: "http://feeds.bbci.co.uk/news/science_and_environment/rss.xml"
					}
				],
				showSourceTitle: true,
				showPublishDate: true,
				broadcastNewsFeeds: true,
				broadcastNewsUpdates: true,
				reloadInterval: 14 * 60 * 1000,
				//frequency of feed entry cycling
				updateInterval: 10 * 60 * 1000,
				//ignore anything older than 12 hrs
				ignoreOlderThan: 12 * 60 * 60 * 1000,
				ignoreOldItems: true,
				showDescription: true,
				truncDescription: false,
				sortOrder: 1,
				feedLabel: "HEADLINE"
			}
		},
		{
			module: "newsfeed",
			position: "bottom_bar",
			config: {
				feeds: [
					{	title: "WHITESOX",
						url: "https://www.mlb.com/whitesox/feeds/news/rss.xml"
					},
					{	title: "MLB",
						/*url: "https://www.mlb.com/feeds/news/rss.xml"*/
					    url: "https://www.espn.com/espn/rss/mlb/news"
					},
					{	title: "NFL", 
						url: "https://www.espn.com/espn/rss/nfl/news"
					}
				],
				showSourceTitle: true,
				showPublishDate: true,
				broadcastNewsFeeds: true,
				broadcastNewsUpdates: true,
				reloadInterval: 14 * 60 * 1000,
				updateInterval: 60 * 10000,
				ignoreOldItems: true,
				ignoreOlderThan: 60 * 60 * 120000,
				showDescription: true,
				truncDescription: false,
				sortOrder: 2,
				feedLabel: "SPORT"
			}
		},
		{
			module: 'MMM-CTA',
			position: 'bottom_right',
			config: {
				updateTime: 300000, /* 5 minute, the API does not update much more often so going below this is unnecessary */
				ctaApiKey: '',
				busStopName: '',  /* String value, Name your bus stop */
				stopId: 30156, /* Bus station ID: Chicago and Milwaukee example; go to http://www.transitchicago.com/riding_cta/systemguide/default.aspx to find your stop ID */
				maxResult: 0,  /* The maximum number of incoming buses you want to display for bus stops */
				ctaApiKeyTrain: '######',
				trainStopName: 'STOPNAME',  /* String value, name your train stop */
				trainStationID: 123456, /* Train station ID:  Chicago Blue line example; http://www.transitchicago.com/developers/ttdocs/default.aspx#_Toc296199909 */
				maxResultTrain: 3, /* Max number of incoming trains to display */
				moduleInstance: 1, /* To run multiple instances of this module */				
				trainIconColor: 'auto'
			}		
	    },
		{
			module: 'MMM-CTA',
			position: 'bottom_right',
			config: {
				//1000 = 1 second
				updateTime: 300000, 
				ctaApiKey: '',
				busStopName: '', 
				stopId: 30126,
				maxResult: 0, 
				ctaApiKeyTrain: '######',
				trainStopName: 'STOPNAME',
				trainStationID: 123456,
				maxResultTrain: 3, 
				moduleInstance: 2, 
				trainIconColor: 'auto'
			}
		},
		{	module: "MMM-HTTPRequestDisplay",
			class: "newsfeed",
			position: "bottom_bar",
			config: {
				httpRequestURL: "https://lapi.transitchicago.com/api/1.0/routes.aspx?type=rail",
				updateInterval: (10 * 60 * 1000)	//10 minutes
			}
		},
		{
			//help prevent LCD screen burnIn
			module: "MMM-BurnIn",
			//position: "bottom_bar",
			config: {
				updateInterval: 3,
				invertDuration: 17
			}
		},	
		{
		module: "MMM-KeyBindings",
			config: {
				evdev: { enabled: false },
				enableKeyboard: true
			}
		}
	]
};

/*************** DO NOT EDIT THE LINE BELOW ***************/
if (typeof module !== "undefined") { module.exports = config; }
